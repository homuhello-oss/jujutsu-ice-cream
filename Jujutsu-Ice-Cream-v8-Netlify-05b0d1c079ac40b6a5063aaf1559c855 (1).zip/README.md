# Jujutsu Ice Cream — A Batalha das Sorveterias

Simulador didático de Gestão de Operações para duas equipes. Gojo e Sukuna disputam cinco rodadas em um festival de sorvetes. Cada equipe escolhe uma regra para organizar os pedidos da sua sorveteria.

## Jogar

1. Extraia o ZIP e abra `index.html` no navegador. As artes e o áudio estão incorporados ao arquivo.
2. Atribua Gojo e Sukuna às equipes. Em cada rodada, consulte a tabela de pedidos e a capacidade das estações.
3. A Equipe 1 escolhe e confirma sua estratégia. A escolha fica reservada até a Equipe 2 confirmar. O cronômetro é opcional.
4. Acompanhe a simulação e compare as três estratégias pelas entregas e pela espera média. As decisões confirmadas e o progresso ficam salvos no navegador.
5. Depois da última rodada, o Panda toca o tambor em tela cheia. A revelação mostra o vencedor, o placar acumulado e os pontos de cada rodada.

## Regras de sequenciamento

| Regra | Prioridade |
| --- | --- |
| **FSFO** — First in the System, First Out | Entre os pedidos disponíveis, começa o que chegou primeiro à sorveteria. |
| **EDD** — Earliest Due Date | Começa o pedido com o menor prazo de entrega. |
| **SOT** — Shortest Operation Time | Começa o pedido com a operação mais curta na estação atual. O primeiro passo é o preparo. |

A tabela mostra a ordem de chegada, a duração do preparo e o prazo de entrega. **Horários e etapas** abre os minutos de chegada, cobertura e embalagem quando a turma precisar consultar esses dados. Após a rodada, o jogo mostra entregas no prazo, atrasos, espera média e uma explicação do desempenho. A pontuação fica reservada para a revelação final.

## Rodadas

| Rodada | Ambiente | Pedidos por sorveteria | Decisão |
| --- | --- | ---: | --- |
| A abertura do festival | Manhã | 3 | Interpretar a ordem de chegada |
| A hora do rush | Início da tarde | 4 | Lidar com preparos curtos e longos na mesma fila |
| Clientes impacientes | Tarde | 4 | Considerar prazos com níveis diferentes de urgência |
| O gargalo | Pôr do sol | 4 | Programar pedidos com postos que abrem mais tarde |
| O grande encerramento | Noite | 6 | Conciliar prazos, tempos de operação e capacidade |

Os clientes têm horários de chegada distintos dentro de cada rodada. Em caso de empate de prioridade, a estação atende o pedido que entrou primeiro na sua fila. A simulação registra o minuto de início e de fim de cada operação.

## Pontuação

- **Nota bruta** = 70 × fração dos pedidos no prazo + 30 × (tempo total de processamento ÷ tempo total de atravessamento).
- **Pontos da rodada** = 100 × nota bruta ÷ maior nota bruta obtida pelas três regras naquela sorveteria.

Entregar no minuto do prazo conta como pontual. O atravessamento mede da chegada até a entrega e a espera soma apenas o tempo nas filas. Cada rodada vale até **100 pontos**, para um total de **500 pontos** em cinco rodadas. Em caso de empate em pontos, vale a maior pontualidade média. Se os dois critérios empatarem, o resultado é compartilhado.

## Publicar no Netlify Drop

1. Abra o [Netlify Drop](https://app.netlify.com/drop).
2. Arraste o ZIP para a área de upload. Também é possível extrair o pacote e arrastar a pasta que contém `index.html` na raiz.
3. Abra a URL que o Netlify fornecer e confira a tela de seleção de personagens.

O projeto é estático e está pronto para servir. A [documentação do Netlify Drop](https://docs.netlify.com/start/quickstarts/netlify-drop-quickstart/) descreve o envio e a atualização de uma publicação.

## Arquivos e manutenção

- `index.html` reúne o HTML, o CSS, o motor, os cenários e os recursos de áudio e imagem. Procure por `global.Scenarios` para editar os dados das rodadas.
- `README.md` contém as instruções de jogo, pontuação e publicação.

A v8 pode retomar uma partida da v7 quando o jogo é aberto no mesmo endereço e navegador. O cenário tem uma imagem estática de segurança para cada rodada caso a renderização do canvas falhe. A cena final inclui o GIF do Panda, o áudio da rufada e uma ilustração para cada vencedor.

## Verificação do simulador

Foram testadas as 30 combinações de regra, rodada e sorveteria. Cada regra alcança a maior pontuação isoladamente em pelo menos um cenário de cada sorveteria. Duas partidas completas em Chromium verificaram as duas vitórias, a mudança de ambiente durante as cinco rodadas e a animação com áudio antes da revelação. A imagem de segurança foi testada durante a perda simulada do canvas entre a quarta e a quinta rodada.
